"""Instrument simulator: writes 6 synthetic measurement files into ./data.

Each run is a train of Gaussian pulses whose amplitude decays exponentially,
on top of a DC offset, with white noise. Values are stored as raw ADC counts;
the calibration factor (V per count) is written in the file header.

Usage:  python scripts/make_data.py
"""
import json
import pathlib

import numpy as np

# name: sampling rate [Hz], duration [s], pulse period [s], first amplitude [V],
#       decay time tau [s], offset [V], noise sigma [V], calibration [V/count], NaN fraction
RUNS = {
    "run01": dict(fs=1000, dur=10, period=0.50, a0=1.0, tau=4.0, offset=0.30, noise=0.03, cal=0.001, nan=0.0),
    "run02": dict(fs=1000, dur=10, period=0.40, a0=1.2, tau=3.0, offset=-0.20, noise=0.05, cal=0.001, nan=0.0),
    "run03": dict(fs=500, dur=12, period=0.25, a0=0.9, tau=6.0, offset=0.60, noise=0.02, cal=0.002, nan=0.0),
    "run04": dict(fs=1000, dur=10, period=0.50, a0=1.0, tau=5.0, offset=0.10, noise=0.04, cal=0.001, nan=0.01),
    "run05": dict(fs=2000, dur=8, period=0.80, a0=1.5, tau=8.0, offset=0.45, noise=0.06, cal=0.0005, nan=0.0),
    "run06": dict(fs=1000, dur=10, period=0.50, a0=0.2, tau=4.0, offset=0.15, noise=0.03, cal=0.001, nan=0.0),
}
PULSE_WIDTH_S = 0.01


def simulate(name, p, seed):
    rng = np.random.default_rng(seed)
    t = np.arange(0, p["dur"], 1.0 / p["fs"])
    volts = np.full_like(t, p["offset"])
    for tk in np.arange(0.25, p["dur"], p["period"]):
        amp = p["a0"] * np.exp(-tk / p["tau"])
        volts += amp * np.exp(-0.5 * ((t - tk) / PULSE_WIDTH_S) ** 2)
    volts += rng.normal(0.0, p["noise"], t.size)
    counts = np.round(volts / p["cal"])
    temp = 22.0 + 0.05 * rng.standard_normal(t.size)
    if p["nan"] > 0:
        bad = rng.choice(t.size, int(p["nan"] * t.size), replace=False)
        counts[bad] = np.nan
    return t, counts, temp


def main():
    out = pathlib.Path(__file__).resolve().parents[1] / "data"
    out.mkdir(exist_ok=True)
    truth = {}
    for i, (name, p) in enumerate(RUNS.items()):
        t, counts, temp = simulate(name, p, seed=1000 + i)
        with open(out / f"{name}.csv", "w") as f:
            f.write("# instrument: PL-200\n")
            f.write(f"# calibration_V_per_count: {p['cal']}\n")
            f.write("time_s,signal_counts,temp_C\n")
            for a, b, c in zip(t, counts, temp):
                f.write(f"{a:.6f},{'' if np.isnan(b) else int(b)},{c:.3f}\n")
        truth[name] = dict(offset_V=p["offset"], dominant_frequency_hz=1.0 / p["period"], tau_s=p["tau"], noise_V=p["noise"])
    (out.parent / "ground_truth.json").write_text(json.dumps(truth, indent=2))
    print("wrote", len(RUNS), "files in", out)


if __name__ == "__main__":
    main()
