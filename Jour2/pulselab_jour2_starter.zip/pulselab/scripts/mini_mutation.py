"""Tiny mutation-testing helper (no external dependency).

For each mutant, one small change is applied to a COPY of the project and the
test suite is run. If the tests still pass, the mutant SURVIVED: your tests
did not notice the change. Improve the tests until (almost) all mutants are killed.

    python scripts/mini_mutation.py
    python scripts/mini_mutation.py --verbose

A survivor is either a missing test, or an "equivalent" mutant (a change that
does not alter the behaviour). Decide which one, and explain why.
"""
import argparse
import pathlib
import shutil
import subprocess
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]

# (id, file, original text, mutated text, what it simulates)
MUTANTS = [
    ("M1", "pulselab/spectrum.py", "1 + np.argmax(spec[1:])", "np.argmax(spec[1:])", "off-by-one on the frequency index"),
    ("M2", "pulselab/spectrum.py", "freqs[1] - freqs[0]", "freqs[1] + freqs[0]", "wrong frequency step in the band power"),
    ("M3", "pulselab/spectrum.py", "(freqs >= fmin) & (freqs <= fmax)", "(freqs > fmin) & (freqs <= fmax)", "band lower edge no longer inclusive"),
    ("M4", "pulselab/spectrum.py", "if not fmin < fmax:", "if not fmin <= fmax:", "fmin == fmax accepted"),
    ("M5", "pulselab/stats.py", "20 * np.log10", "10 * np.log10", "SNR convention changed"),
    ("M6", "pulselab/stats.py", "np.max(x) - np.min(x)", "np.max(x) + np.min(x)", "peak-to-peak computed as a sum"),
    ("M7", "pulselab/preprocess.py", "x - np.mean(x)", "x - np.median(x)", "median instead of mean"),
    ("M8", "pulselab/preprocess.py", "np.sqrt(2)", "2", "noise normalisation removed"),
    ("M9", "pulselab/peaks.py", "(mid > thr)", "(mid >= thr)", "threshold comparison relaxed"),
    ("M10", "pulselab/peaks.py", "i - last >= gap", "i - last > gap", "minimum gap off by one"),
    ("M11", "pulselab/fit.py", "or 1.0", "or 2.0", "fallback initial guess for tau"),
    ("M12", "pulselab/io.py", "np.median(np.diff(t))", "np.mean(np.diff(t))", "median sampling step replaced by mean"),
]


def run_tests(project):
    r = subprocess.run([sys.executable, "-m", "pytest", "-x", "-q", "-p", "no:cacheprovider"],
                       cwd=project, capture_output=True, text=True)
    return r.returncode == 0, r.stdout[-400:]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    ok, out = run_tests(ROOT)
    if not ok:
        sys.exit("The test suite must pass BEFORE mutation testing:\n" + out)

    killed = survived = skipped = 0
    for mid, rel, old, new, why in MUTANTS:
        with tempfile.TemporaryDirectory() as tmp:
            proj = pathlib.Path(tmp) / "p"
            shutil.copytree(ROOT, proj, ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache", ".git", ".venv", ".coverage"))
            target = proj / rel
            text = target.read_text()
            if old not in text:
                print(f"{mid:4} SKIPPED   {rel}: text not found (code changed?)")
                skipped += 1
                continue
            target.write_text(text.replace(old, new, 1))
            passed, out = run_tests(proj)
        if passed:
            survived += 1
            print(f"{mid:4} SURVIVED  {rel}: {why}")
        else:
            killed += 1
            print(f"{mid:4} killed    {rel}: {why}")
    total = killed + survived
    print(f"\nMutation score: {killed}/{total} killed ({100 * killed / max(total, 1):.0f}%), {skipped} skipped")


if __name__ == "__main__":
    main()
