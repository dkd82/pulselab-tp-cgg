"""Time find_pulses on a long synthetic signal.

python scripts/benchmark.py
"""
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pulselab.peaks import find_pulses


def make_signal(n=2_000_000, fs=1000.0, seed=0):
    rng = np.random.default_rng(seed)
    x = rng.normal(0.0, 0.05, n)
    half = int(0.05 * fs)
    local_t = np.arange(-half, half + 1) / fs
    pulse = 0.8 * np.exp(-0.5 * (local_t / 0.01) ** 2)
    for c in range(int(0.25 * fs), n - half - 1, int(0.5 * fs)):
        x[c - half:c + half + 1] += pulse
    return x, fs


if __name__ == "__main__":
    x, fs = make_signal()
    t0 = time.perf_counter()
    idx = find_pulses(x, fs)
    dt = time.perf_counter() - t0
    print(f"{len(idx)} pulses found in {dt:.3f} s  (checksum {int(idx.sum())})")
