import numpy as np

from pulselab import config


def find_pulses(x, fs):
    """Indices of the pulses in x: local maxima above the threshold,
    at least min_gap_s apart (the first one of a group wins)."""
    x = np.asarray(x)
    thr = config.CONFIG["threshold_v"]
    gap = int(config.CONFIG["min_gap_s"] * fs)
    mid = x[1:-1]
    candidates = np.flatnonzero((mid > thr) & (mid > x[:-2]) & (mid >= x[2:])) + 1
    peaks = []
    last = -10**9
    for i in candidates:  # short loop: candidates only, not every sample
        if i - last >= gap:
            peaks.append(i)
            last = i
    return np.array(peaks, dtype=int)
