import numpy as np
from scipy.signal import welch


def dominant_frequency(x, fs):
    """Frequency [Hz] of the largest non-DC peak of the spectrum."""
    x = np.asarray(x, dtype=float)
    spec = np.abs(np.fft.rfft(x - np.mean(x)))
    freqs = np.fft.rfftfreq(len(x), d=1.0 / fs)
    return float(freqs[1 + np.argmax(spec[1:])])


def band_power(x, fs, fmin, fmax, nperseg=1024):
    """Power [unit^2] of x in the band [fmin, fmax] Hz, from a Welch PSD."""
    if not fmin < fmax:
        raise ValueError("fmin must be smaller than fmax")
    x = np.asarray(x, dtype=float)
    freqs, psd = welch(x, fs=fs, nperseg=min(nperseg, len(x)))
    df = freqs[1] - freqs[0]
    mask = (freqs >= fmin) & (freqs <= fmax)
    return float(np.sum(psd[mask]) * df)
