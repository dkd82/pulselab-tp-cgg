import csv
import glob
import os

import numpy as np

from pulselab import config
from pulselab.fit import fit_decay
from pulselab.io import load_run
from pulselab.peaks import find_pulses
from pulselab.preprocess import estimate_noise, moving_average, remove_offset
from pulselab.spectrum import band_power, dominant_frequency
from pulselab.stats import peak_to_peak, rms, snr_db

COLUMNS = ["run", "n_samples", "fs_hz", "offset_V", "p2p_V", "noise_V",
           "snr_db", "dom_freq_hz", "n_pulses", "pulse_rate_hz", "tau_s"]


def analyze_run(run):
    """Summary statistics of one run (a dict returned by load_run)."""
    raw = run["signal"]
    offset = float(np.mean(raw))
    sig = remove_offset(raw)          # a copy: run["signal"] is never modified
    noise = estimate_noise(sig)
    p2p = peak_to_peak(sig)
    smooth = moving_average(sig, max(3, int(0.008 * run["fs"])))
    idx = find_pulses(smooth, run["fs"])
    duration = run["t"][-1] - run["t"][0]
    tau = fit_decay(run["t"][idx], sig[idx])
    row = {
        "run": run["name"],
        "n_samples": len(sig),
        "fs_hz": run["fs"],
        "offset_V": offset,
        "p2p_V": p2p,
        "noise_V": noise,
        "snr_db": snr_db(rms(sig), noise),
        "dom_freq_hz": dominant_frequency(sig, run["fs"]),
        "n_pulses": len(idx),
        "pulse_rate_hz": len(idx) / duration,
        "tau_s": tau,
    }
    band = config.CONFIG["band"]
    if band is not None:
        row["band_power_V2"] = band_power(sig, run["fs"], band[0], band[1])
    return row


def analyze_folder(folder):
    rows = []
    for path in sorted(glob.glob(os.path.join(folder, "*.csv"))):
        run = load_run(path)
        rows.append(analyze_run(run))
    return rows


def write_summary(rows, path):
    columns = COLUMNS + (["band_power_V2"] if rows and "band_power_V2" in rows[0] else [])
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(columns)
        for r in rows:
            w.writerow([r[c] if c == "run" else f"{r[c]:.6f}" if isinstance(r[c], float) else r[c] for c in columns])
    if config.CONFIG["verbose"]:
        print("summary written to", path)


def print_table(rows):
    print("%-6s %8s %8s %9s %8s %8s %8s %9s %8s %8s" % ("run", "n", "fs", "offset", "p2p", "noise", "snr", "f_dom", "pulses", "tau"))
    for r in rows:
        print("%-6s %8d %8.1f %9.4f %8.4f %8.4f %8.2f %9.3f %8d %8.3f" % (
            r["run"], r["n_samples"], r["fs_hz"], r["offset_V"], r["p2p_V"], r["noise_V"],
            r["snr_db"], r["dom_freq_hz"], r["n_pulses"], r["tau_s"]))
