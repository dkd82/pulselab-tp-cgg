import os

import numpy as np
import pandas as pd

from pulselab import config


def load_run(path):
    """Load one measurement file and return a dict."""
    meta = {}
    with open(path) as f:
        for line in f:
            if not line.startswith("#"):
                break
            if ":" in line:
                k, v = line[1:].split(":", 1)
                meta[k.strip()] = v.strip()

    df = pd.read_csv(path, comment="#")
    cal = float(meta.get("calibration_V_per_count", 1.0))
    df = df.dropna(subset=["signal_counts"])
    t = df["time_s"].to_numpy()
    sig = df["signal_counts"].to_numpy() * cal
    fs = 1.0 / np.median(np.diff(t))

    if config.CONFIG["verbose"]:
        print("loaded", path, len(t), "samples, fs =", round(fs, 1))
    return {
        "name": os.path.splitext(os.path.basename(path))[0],
        "t": t,
        "signal": sig,
        "temp": df["temp_C"].to_numpy(),
        "fs": fs,
        "meta": meta,
    }
