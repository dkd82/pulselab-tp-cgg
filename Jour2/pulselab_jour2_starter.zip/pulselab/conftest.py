# Makes `import pulselab` work when running `pytest` from the project root.
