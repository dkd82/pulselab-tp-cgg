import numpy as np
import pytest

from pulselab.spectrum import band_power

FS = 1000.0
T = np.arange(0, 10, 1 / FS)


def test_sine_power_inside_band():
    x = 2.0 * np.sin(2 * np.pi * 50.0 * T)
    assert band_power(x, FS, 40, 60) == pytest.approx(2.0, rel=0.05)


def test_invalid_band_raises():
    with pytest.raises(ValueError):
        band_power(np.zeros(100), FS, 60, 40)
