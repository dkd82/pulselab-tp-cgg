import numpy as np

from pulselab.spectrum import dominant_frequency


def test_dominant_frequency_of_a_sine():
    fs = 1000.0
    t = np.arange(0, 2, 1 / fs)
    x = np.sin(2 * np.pi * 5.0 * t) + 0.3
    assert abs(dominant_frequency(x, fs) - 5.0) < 0.5
