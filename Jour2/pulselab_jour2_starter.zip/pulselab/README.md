# pulselab

Petite boîte à outils d'analyse pour des mesures de trains d'impulsions bruités
(offset, bruit, SNR, fréquence dominante, nombre d'impulsions, temps de décroissance, puissance de bande optionnelle).

## Installation

    pip install -r requirements.txt

## Usage

    python scripts/run_analysis.py --data data --out summary.csv
    python scripts/run_analysis.py --data data --out summary.csv --band 1 5

`--band FMIN FMAX` ajoute une colonne `band_power_V2` : la puissance du signal (V^2) entre
FMIN et FMAX Hz, intégrée à partir d'une densité spectrale de puissance de Welch.

## Tests

    python -m pytest -q

## Données

Les fichiers dans `data/` sont des CSV, avec un court en-tête `#` (instrument, calibration en
V par compte). Régénérez-les avec `python scripts/make_data.py`.
