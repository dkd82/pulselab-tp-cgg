# pulselab

Petite boîte à outils d'analyse pour des mesures de trains d'impulsions bruités
(offset, bruit, SNR, fréquence dominante, nombre d'impulsions, temps de décroissance).

## Usage

    python run_analysis.py --data data --out summary.csv

## Données

Les fichiers dans `data/` sont des CSV, avec un court en-tête `#` (instrument, calibration).
