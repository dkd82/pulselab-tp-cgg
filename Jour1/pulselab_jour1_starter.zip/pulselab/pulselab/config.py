"""Global configuration (module-level state, edited by the scripts)."""

CONFIG = {
    "threshold_v": 0.25,   # pulse detection threshold [V]
    "min_gap_s": 0.05,     # minimum time between two pulses [s]
    "verbose": True,
}
