import numpy as np


def rms(x):
    return float(np.sqrt(np.mean(np.square(x))))


def peak_to_peak(x):
    return float(np.max(x) - np.min(x))


def snr_db(signal_rms, noise):
    """Signal-to-noise ratio in dB."""
    return float(10 * np.log10(signal_rms / noise))
