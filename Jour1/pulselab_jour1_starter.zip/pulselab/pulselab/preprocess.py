import numpy as np


def remove_offset(x):
    """Remove the mean of x (done in place, to save memory)."""
    x -= np.mean(x)
    return x


def moving_average(x, n):
    return np.convolve(x, np.ones(n) / n, mode="same")


def estimate_noise(x):
    """White-noise sigma estimated from the first differences."""
    x = remove_offset(x)
    return float(np.std(np.diff(x)) / np.sqrt(2))
